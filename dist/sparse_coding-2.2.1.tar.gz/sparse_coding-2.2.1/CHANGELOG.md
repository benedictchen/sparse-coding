# Changelog - sparse_coding

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- Migrated from overlooked_classics_libraries structure
- Initial package structure with tests and examples

### Changed
- Organized into research-focused directory structure

## [1.0.0] - Initial Release
- Initial implementation based on research papers
